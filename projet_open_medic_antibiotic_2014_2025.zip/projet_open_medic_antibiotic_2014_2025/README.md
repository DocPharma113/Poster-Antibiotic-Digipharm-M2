# Antibiotiques délivrés en ville en France (Open Medic, ATC J01), 2014-2025

Projet du M2 DigiPharm (Aix-Marseille Université), UE Research Project.

## Question
Comment ont évolué les antibiotiques (classe ATC J01) délivrés en pharmacie de ville ? La période Covid est-elle une rupture ? Y a-t-il des différences selon les sous-classes, l'âge, le sexe et la région ?

## Contenu du dépôt
- `open_medic_j01.ipynb` : le notebook (lecture, nettoyage, graphiques, ratio par région, k-means et ACP)
- `population.csv` : population INSEE au 1er janvier (région, sexe, 3 tranches d'âge)
- `figures/` : graphiques produits par le notebook
- `resultats_cles.csv` : quelques chiffres clés
- `donnees/` : à remplir avec les fichiers Open Medic (voir `donnees/LISEZ-MOI.txt`)

## Lancer le notebook
1. Installer les bibliothèques : `pip install -r requirements.txt`
2. Mettre les fichiers Open Medic dans `donnees/`
3. Ouvrir le notebook avec Jupyter et choisir *Kernel > Restart & Run All*

## Résultats principaux (années 2014-2025)
- 1 725 boîtes pour 1 000 habitants en 2019, 1 363 en 2020 : **−21 %**, soit environ 20 % sous la tendance 2014-2019 prolongée.
- Baisse 2019 → 2020 la plus forte chez les 0-19 ans (−33 %).
- À âge et sexe égaux (2025), PACA (1,15) et Hauts-de-France (1,14) sont au-dessus de la moyenne ; Pays de la Loire (0,82) et Bretagne (0,89) en dessous.
- Témoin paracétamol (classe N02B) : environ −2 % en 2020 contre −21 % pour les antibiotiques (indice base 100 en 2019). La baisse des antibiotiques n'est donc pas seulement liée à l'accès aux soins.
- Le k-means donne 2 groupes de régions peu séparés (silhouette 0,30) : analyse exploratoire.

## Limites
- Une boîte n'est pas une dose. Données de ville uniquement. Association, pas preuve de cause.
- Code région 5 = outre-mer (confirmé par le tuteur) ; Mayotte (caisse d'assurance maladie à part) est peut-être absente, ce qui expliquerait un ratio environ deux fois plus faible.
- PACA et Corse regroupées, anciens noms de régions conservés dans Open Medic (confirmé par le tuteur).
- N02B n'est pas du paracétamol pur, et Open Medic ne contient que les médicaments remboursés.
- À vérifier : la signification des codes d'âge et de sexe.
- Données régionales 2025 : vérifier la version corrigée sur data.gouv.fr, ou mettre `annee_ref = 2023` dans le notebook.

## Sources
- Assurance Maladie, *Open Medic* (data.gouv.fr)
- INSEE, *Estimation de la population au 1er janvier* : https://www.insee.fr/fr/statistiques/8721456
